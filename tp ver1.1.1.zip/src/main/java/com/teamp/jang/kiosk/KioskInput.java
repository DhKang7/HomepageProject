package com.teamp.jang.kiosk;

import lombok.Data;

@Data
public class KioskInput {
	private String i_name;
	private String selected1;
	private String selected2;
	private String selected3;
	private String selected4;
	
	
	
}
